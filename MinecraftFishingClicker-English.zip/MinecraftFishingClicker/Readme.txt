Minecraft auto-fishing clicker

How to use
1.Make an AFK fishing farm.
2.Equip a fishing rod.
3.Press ESC to pause.
4.Move the cursor over the hook tip.
5.Press P to save the coordinates.
6.Get ready to fish, then press O.
7.Press O again to stop.

Threshold settings
1.Get the color value while holding a fishing rod.
2.Check the color value when no fishing rod is equipped.
3.Set the midpoint value as the threshold.

Usage tips
1.Block out sunlight and keep the brightness constant using torches.
2.Place a dark block behind the fishing rod.
3.Prevent your cat from moving the mouse.


Application developer	YagiG
IDE			Delphi CE

https://github.com/Yagi-G/MinecraftBE-FishingClicker